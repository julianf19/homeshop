package com.example.alexandre.puisage2;

import java.sql.Time;
import java.util.HashMap;
import java.util.List;

public class Output {



    public static boolean testEntry(String room) {
//test if present in cvs
        //add to csv
        //add entry time
        return false;

        //else add exiting time
        //
        //return true
    }




}
