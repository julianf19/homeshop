package com.example.alexandre.puisage2;

import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RoomsActivity extends AppCompatActivity{

private List<String> Rooms = new ArrayList<>();


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        populateFirstListView();;
        registerClickCallback();

    }


    private void populateFirstListView() {


        String[] myTestList = {"-2G290","-2L028","-5G594","45G949","-2L028","-5G594","45G949","-2L028","-5G594","45G949","-2L028","-5G594","45G949"};
        Rooms.addAll(Arrays.asList(myTestList));


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_list,Rooms);

        ListView list = findViewById(R.id.mobile_list);
        list.setAdapter(adapter);
    }
    private void populateListView() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_list,Rooms);

        ListView list = findViewById(R.id.mobile_list);
        list.setAdapter(adapter);
    }

    private void registerClickCallback() {

        ListView list = findViewById(R.id.mobile_list);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View viewClicked, int position, long id) {
                TextView textView=(TextView) viewClicked;
                Rooms.remove(position);


                String message = "you clicked" + textView.getText().toString();
                Toast.makeText(RoomsActivity.this, message, Toast.LENGTH_SHORT).show();
                populateListView();
                setClickTime(textView.getText().toString());

            }

        });
    }

    private void setClickTime(String room){
        boolean testEntry=Output.testEntry(room);
        if (!testEntry)
        Rooms.add(0,room);



    }



}
